var React = require("react");
var ReactDOM = require("react-dom");

export default class App extends React.Component{
    render(){
        return <h1>hello reactJs</h1>
    }
}